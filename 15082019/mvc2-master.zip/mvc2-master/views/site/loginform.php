<form action="<?= $loginURL ?>" method="POST" class="loginForm">
    <input type="text" name="user" placeholder="User">
    <input type="password" name="pass" placeholder="Password">
    <input type="submit" value="Login">
</form>