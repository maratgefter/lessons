<?php
/* @var $this View */
/** @var string $title */
?><!DOCTYPE html>
<html lang="en">
<head>
    <base href="/">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<ul class="menu">
    <li>
        <a href="?a=home">Home</a>
    </li>
    <li>
        <a href="one">tableOne</a>
    </li>
    <li>
        <a href="two">tableTwo</a>
    </li>
    <li>
        <a href="group">UserGroup</a>
    </li>
    <li>
        <a href="user">Users</a>
    </li>
    <li>
        <a href="?a=loginform">login</a>
    </li>
    <li>
        <a href="?a=logout">logout</a>
    </li>
    <li>
        <a href="?a=about">about</a>
    </li>
</ul>
<div class="status"><?= Auth::currentUserInfo() ?></div>

<?= ErrorHandler::read() ?>
<div id="maincontent">
    <?php $this->body(); ?>
</div>

</body>

</html>