<?php

class  TableOneController extends AbstractTableController
{
    public $tableName = 'categories';
}