<?php

class  UserGroupController extends AbstractTableController
{
    public $tableName = 'user_group';
}