<?php

class  TableTwoController extends AbstractTableController
{
    public $tableName = 'products';
}