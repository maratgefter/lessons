<?php
namespace my_space;

class tclass
{ }
